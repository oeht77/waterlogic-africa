# LandTech Africa

Smart tools and reports for land and water management.